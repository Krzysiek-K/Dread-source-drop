

==== Dread version 1C23 - exclusive for Patreon patrons ====


    Please insert Disk 2 after the game loads to access extra custom maps!
    (or play them right away if you happen to have a HDD)



* Dread - an FPS game for Amiga 500/1200 & Atari ST

    By:
        KK/Altair    (Krzysztof Kluczek)
        John Tsakiris
        Dennis Ramberg
        DMA-SC
        using assets from The Freedoom Project


    Custom maps by:
        Jammer      - Big Concrete
	LaBodilsen  - DS_Portland
	m3_mapper   - Uberkoph
	Tsak        - BigMapRemake
	Wuerfel21   - Chasm




* Please consider:

    - supporting via Patreon:        https://www.patreon.com/kk_altair
    - visiting my YouTube channel:   https://www.youtube.com/c/KKAltair
    - joining our Discord server:    https://discord.gg/zKCeXxC6nU




Have fun!
KK/Altair
