

==== Dread version 2629 - exclusive for Patreon patrons ====


    This release contains one map - the Big Map upgraded by John Tsakiris.
    Have fun!



* Dread - an FPS game for Amiga 500/1200 & Atari ST

    By:
        KK/Altair    (Krzysztof Kluczek)
        John Tsakiris
        Dennis Ramberg
        DMA-SC
        using assets from The Freedoom Project




* Please consider:

    - supporting via Patreon:        https://www.patreon.com/kk_altair
    - visiting my YouTube channel:   https://www.youtube.com/c/KKAltair
    - joining our Discord server:    https://discord.gg/zKCeXxC6nU




Have fun!
KK/Altair
