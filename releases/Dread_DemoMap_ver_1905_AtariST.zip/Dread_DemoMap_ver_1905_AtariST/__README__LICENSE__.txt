
* Dread - an FPS game for Amiga 500/1200 & Atari ST

    By:
        KK/Altair    (Krzysztof Kluczek)
        John Tsakiris
        Dennis Ramberg
        DMA-SC
        using assets from The Freedoom Project



* Please consider:

    - supporting via Patreon:        https://www.patreon.com/kk_altair
    - visiting my YouTube channel:   https://www.youtube.com/c/KKAltair
    - joining our Discord server:    https://discord.gg/zKCeXxC6nU


* Please:

    - DO NOT redistribute or host this pack nor any files here yourself, in their original form or modified
    - DO NOT link directly to download this file - instead link to the release video ( https://youtu.be/ZxhO1ZCOZ-M )
    - DO NOT create derivative works directly using the contents of these files (e.g. compilations, cracks, etc.)

    Please contact me on Discord if you'd like a waiver on any of these rules.


* Instead, you get a license and are encouraged to:

    - Download these files from the officially posted links (e.g. in video descriptions on KK/Altair channel).
    - Use these files for any personal or editorial use (e.g. playing on Amiga or emulator, producing press coverage, etc).
    - Share the link to the official release video ( https://youtu.be/ZxhO1ZCOZ-M )
    - Capture, record and share any material createted while using this product (e.g. screenhots, walkthroughs or commentaries)


Have fun!
KK/Altair
