Dread remake of 3D section from Wildcat demo.

Initial version by LaBodilsen.
Improved and retextured by KK/Altair.
