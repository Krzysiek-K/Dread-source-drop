
Feel free to swap these maps with the ones already existing in the "maps" directory.

Dread menu system can currently list up to 8 maps in the map selector,
so I moved the test maps away.

Have fun,
KK
