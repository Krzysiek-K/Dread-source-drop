

==== Dread preview 2514 - exclusive for Patreon patrons ====


    The story so far:

    You were designated for a reconnaissance mission to a defunct chemical processing plant,
    that was recently hit by a meteor shower. What was being processed there... is a classified
    information, but rumor has it some substance there started reacting with local plant life,
    so the unit was decommissioned. Now, your mission is to assess the damage and if anything
    out of ordinary is found, initiate self destruction by activating three pumps to overload
    the main fuel tank. Somewhere inside you already feel this will happen inevitably.




* Dread - an FPS game for Amiga 500/1200 & Atari ST

    By:
        KK/Altair    (Krzysztof Kluczek)
        John Tsakiris
        Dennis Ramberg
        DMA-SC
        using assets from The Freedoom Project




* Please consider:

    - supporting via Patreon:        https://www.patreon.com/kk_altair
    - visiting my YouTube channel:   https://www.youtube.com/c/KKAltair
    - joining our Discord server:    https://discord.gg/zKCeXxC6nU




Have fun!
KK/Altair
