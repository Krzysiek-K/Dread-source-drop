

==== Dread version 1A08 - the Demo Map update exclusive for Patreon patrons ====




* Dread - an FPS game for Amiga 500/1200 & Atari ST

    By:
        KK/Altair    (Krzysztof Kluczek)
        John Tsakiris
        Dennis Ramberg
        DMA-SC
        using assets from The Freedoom Project



* Please consider:

    - supporting via Patreon:        https://www.patreon.com/kk_altair
    - visiting my YouTube channel:   https://www.youtube.com/c/KKAltair
    - joining our Discord server:    https://discord.gg/zKCeXxC6nU




Have fun!
KK/Altair
