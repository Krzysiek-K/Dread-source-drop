

==== Dread version 1A31 - exclusive for Patreon patrons ====


    This is the first public version, that loads maps from disk or HDD.
    (at least in theory, as it was not largely tested)

    You can put the "Dread" directory on your HDD to enjoy all the maps,
    or enjoy three of them on FDD in the attached ADF (sorry, more didn't fit).

    Have fun!



* Dread - an FPS game for Amiga 500/1200 & Atari ST

    By:
        KK/Altair    (Krzysztof Kluczek)
        John Tsakiris
        Dennis Ramberg
        DMA-SC
        using assets from The Freedoom Project


    With some help from LaBodilsen in recreating Wildcat 3D map.



* Please consider:

    - supporting via Patreon:        https://www.patreon.com/kk_altair
    - visiting my YouTube channel:   https://www.youtube.com/c/KKAltair
    - joining our Discord server:    https://discord.gg/zKCeXxC6nU




Have fun!
KK/Altair
