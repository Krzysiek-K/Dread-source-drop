
Useful links:

 - Documentation wiki:    http://devkk.net/wiki/index.php/Dreadtool
 - Dread Discord server:  https://discord.gg/zKCeXxC6nU
 - KK's Patreon page:     https://www.patreon.com/kk_altair


Have fun!
