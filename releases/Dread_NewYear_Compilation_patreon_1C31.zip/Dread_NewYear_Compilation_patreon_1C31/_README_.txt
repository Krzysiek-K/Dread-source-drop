

==== Dread version 1C31 - exclusive for Patreon patrons ====


    Boot the game from either Disk 1 or Disk 2 - both are bootable.
    Disk 1 contains mostly my maps.
    Disk 2 contains custom maps from Dread contributors.



* Dread - an FPS game for Amiga 500/1200 & Atari ST

    By:
        KK/Altair    (Krzysztof Kluczek)
        John Tsakiris
        Dennis Ramberg
        DMA-SC
        using assets from The Freedoom Project


    Custom maps by:
        Jammer      - Big Concrete
	LaBodilsen  - DS_Portland, Wildcat3D
	m3_mapper   - Uberkoph
	Tsak        - BigMapRemake
	Wuerfel21   - Chasm, TechBase




* Please consider:

    - supporting via Patreon:        https://www.patreon.com/kk_altair
    - visiting my YouTube channel:   https://www.youtube.com/c/KKAltair
    - joining our Discord server:    https://discord.gg/zKCeXxC6nU




Have fun!
KK/Altair
